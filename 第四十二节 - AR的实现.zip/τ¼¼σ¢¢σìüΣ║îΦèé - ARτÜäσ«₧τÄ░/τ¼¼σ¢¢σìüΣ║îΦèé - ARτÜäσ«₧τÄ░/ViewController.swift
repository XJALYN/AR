//
//  ViewController.swift
//  第四十二节 - AR的实现
//
//  Created by xu jie on 2017/4/23.
//  Copyright © 2017年 xujie. All rights reserved.
//

import UIKit
import SceneKit


class ViewController: UIViewController {
   var arView:ARView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 创建AR场景
        self.arView = ARView(frame: UIScreen.main.bounds)
        self.view.addSubview(self.arView)
        
        // 添加3D 文件
        let url =  Bundle.main.url(forResource: "boss_attack", withExtension: "dae")
        self.arView.addModelFile(file: url!, position: SCNVector3Make(0, 0, -1000))
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

  
}

